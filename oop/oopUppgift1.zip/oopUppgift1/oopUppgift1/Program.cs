﻿using System;

namespace oopUppgift1
{
    class Program
    {
        static void Main(string[] args)
        {
            //Elvever
            Person Jobson = new Person("Axel Jobson", 18, 70, 2003);

            Person Jörnulf = new Person("Axel Jörnulf", 19, 110, 2002);

            Person Lindblad = new Person("Axel Lindblad", 18, 67, 2003);

            Person Frans = new Person("Frans Karlsson", 18, 60, 2003);

            Person Sturesson = new Person("Axel Sturesson", 18, 75, 2003);

            Person Adam = new Person("Adam Al-Badre", 18, 70, 2003);

            Person Arvid = new Person("Arvid Andersson", 18, 70, 2003);

            Person OliverB = new Person("Oliver Bergström", 18, 70, 2003);

            Person OliverDT = new Person("Oliver Davcev Talcoth", 18, 70, 2003);

            // Kurser
            Kurs Fysik = new Kurs("Fysik2", "FYSFYS02", "27/08/2021", "03/06/2022");

            Kurs Matte = new Kurs("Matte4", "MATMAT04", "27/08/2021", "03/06/2022");

            Kurs Kemi = new Kurs("Kemi1", "KEMKEM01", "27/08/2021", "03/06/2022");

            Kurs Programmering2 = new Kurs("Programmering", "PRRPRR02", "27/08/2021", "03/06/2022");

            Kurs Svenska3 = new Kurs("Svenska", "SVESVE03", "27/08/2021", "03/06/2022");

            Kurs Webbserver = new Kurs("Webbserver", "WESWEB01", "27/08/2021", "03/06/2022");

            Kurs Webbutveckling = new Kurs("Webbutveckling", "WEUWEB01", "27/08/2021", "03/06/2022");



            Svenska3.Description();
            Jobson.Introduce();


        }
    }
}
